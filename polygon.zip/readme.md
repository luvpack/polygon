# Polygon

Beautiful & simple screen recorder.